package com.springframework.bootstrap;

import com.springframework.entity.*;
import com.springframework.repositories.CategoryRepository;
import com.springframework.repositories.RecipeRepository;
import com.springframework.repositories.UnitOfMeasureRepository;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Component
public class RecipeBootstrap implements ApplicationListener<ContextRefreshedEvent> {

    private final CategoryRepository categoryRepository;
    private final RecipeRepository recipeRepository;
    private final UnitOfMeasureRepository unitOfMeasureRepository;

    public RecipeBootstrap(CategoryRepository categoryRepository, RecipeRepository recipeRepository, UnitOfMeasureRepository unitOfMeasureRepository) {
        this.categoryRepository = categoryRepository;
        this.recipeRepository = recipeRepository;
        this.unitOfMeasureRepository = unitOfMeasureRepository;
    }

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        recipeRepository.saveAll(getRecipes());
    }

    private List<Recipe> getRecipes() {
        List<Recipe> recipes = new ArrayList<>(2);

        List<String> allUnitsDescriptions = Arrays.asList("Teaspoon", "Tablespoon", "Cup", "Ounce", "Each", "Milliliters", "Milligrams");
        Map<String, UnitOfMeasure> allUnitsOfMeasure = new HashMap<>();

        for (String currentUnitOfMeasure : allUnitsDescriptions) {
            Optional<UnitOfMeasure> optionalUnitOfMeasure = unitOfMeasureRepository.findByDescription(currentUnitOfMeasure);

            if (!optionalUnitOfMeasure.isPresent()) {
                throw new RuntimeException("Expected UOM Not Found");
            }

            allUnitsOfMeasure.put(currentUnitOfMeasure, optionalUnitOfMeasure.get());
        }


        List<String> allCategoriesNames = Arrays.asList("Breakfast", "Lunch", "Dinner");
        Map<String, Category> allCategories = new HashMap<>();

        for (String categoryName : allCategoriesNames) {
            Optional<Category> optionalCategory = categoryRepository.findByDescription(categoryName);

            if (!optionalCategory.isPresent()) {
                throw new RuntimeException("Expected Category Not Found");
            }

            allCategories.put(categoryName, optionalCategory.get());
        }

        Recipe frittata = new Recipe();
        frittata.setDescription("Frittata");
        frittata.setPrepTime(10);
        frittata.setCookTime(5);
        frittata.setDifficulty(Difficulty.EASY);
        frittata.setDirections("Preheat the Oven: Preheat your oven broiler.\n" +
                "\n" +
                "Whisk Eggs: In a bowl, whisk together the eggs, milk, salt, and pepper until well combined.\n" +
                "\n" +
                "Prepare Vegetables: Heat olive oil in an oven-safe skillet over medium heat. Add the chopped onion and cook until softened, about 2-3 minutes. Add the diced bell pepper and cook for an additional 2 minutes. Add the cherry tomatoes and spinach, cooking until the spinach wilts and the tomatoes soften.\n" +
                "\n" +
                "Add Eggs: Pour the whisked egg mixture over the vegetables in the skillet. Allow it to cook undisturbed for a few minutes until the edges start to set.\n" +
                "\n" +
                "Add Cheese and Optional Ingredients: Sprinkle the grated Parmesan cheese over the top of the frittata. If you're using ham or bacon, scatter it evenly across the eggs.\n" +
                "\n" +
                "Broil in the Oven: Transfer the skillet to the preheated oven and broil for 3-5 minutes or until the top is set and slightly golden. Keep a close eye to avoid overcooking.\n" +
                "\n" +
                "Serve: Remove from the oven and let it cool for a couple of minutes. Slice into wedges and serve hot.");

        Notes frittataNotes = new Notes();
        frittataNotes.setRecipeNotes("Vegetable Variations: Feel free to customize your frittata with other vegetables like mushrooms, zucchini, or asparagus.\n" +
                "\n" +
                "Cheese Options: Experiment with different cheeses such as feta, mozzarella, or cheddar for varied flavors.\n" +
                "\n" +
                "Fresh Herbs: Add freshness with herbs like parsley, chives, or basil.\n" +
                "\n" +
                "Serve with a Side Salad: A simple side salad with mixed greens and a light vinaigrette pairs well with a frittata.");

        frittata.setNotes(frittataNotes);
        frittataNotes.setRecipe(frittata);

        frittata.addIngredient(new Ingredient("Large eggs", new BigDecimal(6), allUnitsOfMeasure.get("Each")));
        frittata.addIngredient(new Ingredient("Cup milk", new BigDecimal(".5"), allUnitsOfMeasure.get("Milliliters")));
        frittata.addIngredient(new Ingredient("Olive oil", new BigDecimal(1), allUnitsOfMeasure.get("Tablespoon")));
        frittata.addIngredient(new Ingredient("Small onion, finely chopped", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        frittata.addIngredient(new Ingredient("Bell pepper, diced", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        frittata.addIngredient(new Ingredient("Cup of cherry tomatoes, halved", new BigDecimal(1), allUnitsOfMeasure.get("Cup")));
        frittata.addIngredient(new Ingredient("Cup of spinach, chopped", new BigDecimal(1), allUnitsOfMeasure.get("Cup")));
        frittata.addIngredient(new Ingredient("Cup grated Parmesan cheese", new BigDecimal(".5"), allUnitsOfMeasure.get("Cup")));

        frittata.getCategories().add(allCategories.get("Breakfast"));

        frittata.setServings(4);

        recipes.add(frittata);

        Recipe heartyTortelliniSoup = new Recipe();
        heartyTortelliniSoup.setDescription("Hearty Tortellini Soup");
        heartyTortelliniSoup.setCookTime(25);
        heartyTortelliniSoup.setPrepTime(15);
        heartyTortelliniSoup.setDifficulty(Difficulty.MODERATE);

        heartyTortelliniSoup.setDirections("Sauté Vegetables: In a large pot, heat olive oil over medium heat. Add chopped onion, carrots, and celery. Sauté until the vegetables are softened, about 5 minutes. Add minced garlic and sauté for an additional 1-2 minutes.\n" +
                "\n" +
                "Add Broth and Tomatoes: Pour in the chicken or vegetable broth and add the diced tomatoes with their juice. Stir in dried oregano, basil, thyme, salt, and pepper. Bring the mixture to a simmer and let it cook for about 10 minutes to allow the flavors to meld.\n" +
                "\n" +
                "Cook Tortellini: Add the refrigerated tortellini to the simmering soup. Cook according to the package instructions, usually for about 7-10 minutes or until the tortellini is tender.\n" +
                "\n" +
                "Add Spinach: Stir in the chopped fresh spinach and cook until wilted, which should only take a couple of minutes.\n" +
                "\n" +
                "Adjust Seasoning: Taste the soup and adjust the seasoning with additional salt and pepper if needed.\n" +
                "\n" +
                "Serve: Ladle the soup into bowls. Optionally, sprinkle grated Parmesan cheese on top and garnish with fresh basil or parsley.");

        Notes heartyTortelliniSoupNote = new Notes();
        heartyTortelliniSoupNote.setRecipeNotes("Tortellini Options: You can use cheese-filled tortellini, but feel free to experiment with other fillings like spinach and ricotta or meat-filled tortellini.\n" +
                "\n" +
                "Vegetarian Option: Use vegetable broth and consider adding extra vegetables like zucchini or bell peppers for a vegetarian version.\n" +
                "\n" +
                "Make-Ahead Tip: This soup reheats well, making it a great option for meal prep. Store any leftovers in an airtight container in the refrigerator.");
        heartyTortelliniSoupNote.setRecipe(heartyTortelliniSoup);
        heartyTortelliniSoup.setNotes(heartyTortelliniSoupNote);

        heartyTortelliniSoup.addIngredient(new Ingredient("Tablespoon olive oil", new BigDecimal(1), allUnitsOfMeasure.get("Tablespoon")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Onion, finely chopped", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Carrots, peeled and diced", new BigDecimal(2), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Celery stalks, diced", new BigDecimal(2), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Cloves garlic, minced", new BigDecimal(3), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Cups of chicken or vegetable broth", new BigDecimal(6), allUnitsOfMeasure.get("Cup")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Can (14 oz) diced tomatoes, undrained", new BigDecimal(1), allUnitsOfMeasure.get("Cup")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Teaspoon dried oregano", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Teaspoon dried basil", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Teaspoon dried thyme", new BigDecimal(".5"), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Salt and pepper to taste", new BigDecimal(8), allUnitsOfMeasure.get("Ounce")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Package (about 20 oz) refrigerated tortellini (cheese or your preferred filling)", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Cups of fresh spinach, chopped", new BigDecimal(3), allUnitsOfMeasure.get("Each")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Cup of grated Parmesan cheese (for serving)", new BigDecimal(".5"), allUnitsOfMeasure.get("Cup")));
        heartyTortelliniSoup.addIngredient(new Ingredient("Fresh basil or parsley for garnish (optional)", new BigDecimal(1), allUnitsOfMeasure.get("Each")));

        heartyTortelliniSoup.getCategories().add(allCategories.get("Lunch"));

        heartyTortelliniSoup.setServings(6);

        recipes.add(heartyTortelliniSoup);

        Recipe italianBoneInPorkLoin = new Recipe();
        italianBoneInPorkLoin.setDescription("Italian Bone-In Pork Loin");
        italianBoneInPorkLoin.setPrepTime(20);
        italianBoneInPorkLoin.setCookTime(80);
        italianBoneInPorkLoin.setDifficulty(Difficulty.HARD);
        italianBoneInPorkLoin.setDirections("Preheat Oven: Preheat your oven to 375°F (190°C).\n" +
                "\n" +
                "Prepare the Pork Loin: Pat the pork loin dry with paper towels. Using a sharp knife, make several small incisions on the surface of the pork loin.\n" +
                "\n" +
                "Seasoning Mixture: In a small bowl, combine minced garlic, chopped rosemary, thyme, sage, salt, and black pepper. Mix well to form a cohesive seasoning mixture.\n" +
                "\n" +
                "Season the Pork Loin: Rub the seasoning mixture evenly over the entire surface of the pork loin, including the incisions you made.\n" +
                "\n" +
                "Sear the Pork: In an oven-safe skillet or roasting pan, heat olive oil over medium-high heat. Sear the pork loin on all sides until golden brown. This helps lock in the flavors.\n" +
                "\n" +
                "Deglaze with Wine and Broth: Pour the dry white wine into the pan, scraping up any browned bits from the bottom. Add the chicken broth.\n" +
                "\n" +
                "Roast in the Oven: Transfer the skillet or roasting pan to the preheated oven. Roast the pork loin for about 1 to 1.5 hours or until the internal temperature reaches 145°F (63°C). Baste the pork with the pan juices every 20-30 minutes.\n" +
                "\n" +
                "Rest and Serve: Once done, remove the pork from the oven, cover it with foil, and let it rest for about 10-15 minutes before slicing.");

        Notes italianBoneInPorkLoinNote = new Notes();
        italianBoneInPorkLoinNote.setRecipeNotes("Internal Temperature: Ensure the pork reaches an internal temperature of 145°F (63°C) for safe consumption. The juices should run clear when the meat is pierced.\n" +
                "\n" +
                "Pan Juices: The pan juices make a delicious natural sauce. You can strain them and serve them alongside the sliced pork.\n" +
                "\n" +
                "Accompaniments: Serve the Italian Bone-In Pork Loin with your favorite side dishes such as roasted vegetables, potatoes, or a simple salad.");

        italianBoneInPorkLoin.setNotes(italianBoneInPorkLoinNote);
        italianBoneInPorkLoinNote.setRecipe(italianBoneInPorkLoin);

        italianBoneInPorkLoin.addIngredient(new Ingredient("Bone-in pork loin roast (about 4-5 pounds)", new BigDecimal(1), allUnitsOfMeasure.get("Each")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Cloves garlic, minced", new BigDecimal(3), allUnitsOfMeasure.get("Each")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Tablespoons fresh rosemary, chopped (or 1 tablespoon dried)", new BigDecimal(1), allUnitsOfMeasure.get("Tablespoon")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Tablespoons fresh thyme, chopped (or 1 tablespoon dried)", new BigDecimal(2), allUnitsOfMeasure.get("Tablespoon")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Tablespoons fresh sage, chopped (or 1 tablespoon dried)", new BigDecimal(2), allUnitsOfMeasure.get("Tablespoon")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Salt and black pepper to taste", new BigDecimal(2), allUnitsOfMeasure.get("Each")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Tablespoons olive oil", new BigDecimal(2), allUnitsOfMeasure.get("Tablespoon")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Cup of dry white wine", new BigDecimal(1), allUnitsOfMeasure.get("Cup")));
        italianBoneInPorkLoin.addIngredient(new Ingredient("Cup chicken broth", new BigDecimal(1), allUnitsOfMeasure.get("Cup")));

        italianBoneInPorkLoin.getCategories().add(allCategories.get("Dinner"));

        italianBoneInPorkLoin.setServings(8);

        recipes.add(italianBoneInPorkLoin);

        return recipes;
    }
}