package com.springframework.commands;

public class NotesCommand {
    private Long id;
    private String recipeNotes;

    public NotesCommand() {
    }

    public NotesCommand(Long id, String recipeNotes) {
        this.id = id;
        this.recipeNotes = recipeNotes;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRecipeNotes() {
        return recipeNotes;
    }

    public void setRecipeNotes(String recipeNotes) {
        this.recipeNotes = recipeNotes;
    }

    @Override
    public String toString() {
        return "NotesCommand{" +
                "id=" + id +
                ", recipeNotes='" + recipeNotes + '\'' +
                '}';
    }
}
