package com.springframework.controllers;

import com.springframework.services.RecipeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/meals")
public class MealsController {

    private final RecipeService recipeService;

    public MealsController(RecipeService recipeService) {
        this.recipeService = recipeService;
    }

    @GetMapping("/breakfast")
    public String breakfast(Model model) {
        model.addAttribute("recipes", recipeService.getRecipes());
        return "breakfast";
    }

    @GetMapping("/lunch")
    public String lunch(Model model) {
        model.addAttribute("recipes", recipeService.getRecipes());
        return "lunch";
    }

    @GetMapping("/dinner")
    public String dinner(Model model) {
        model.addAttribute("recipes", recipeService.getRecipes());
        return "dinner";
    }
}
