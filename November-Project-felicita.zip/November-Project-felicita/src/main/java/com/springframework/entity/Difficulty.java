package com.springframework.entity;

public enum Difficulty {
    EASY, MODERATE, KIND_OF_HARD, HARD
}
