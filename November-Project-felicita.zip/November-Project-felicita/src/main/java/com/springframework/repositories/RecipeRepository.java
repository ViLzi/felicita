package com.springframework.repositories;

import com.springframework.entity.Recipe;
import org.springframework.data.repository.CrudRepository;



public interface RecipeRepository extends CrudRepository<Recipe, Long> {
}
